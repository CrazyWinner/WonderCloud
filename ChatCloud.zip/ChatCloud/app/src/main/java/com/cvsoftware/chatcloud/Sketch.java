package com.cvsoftware.chatcloud;


import android.util.Log;

import processing.core.PApplet;
import processing.core.PGraphics;

public class Sketch extends PApplet {
    public void settings() {
        size(600, 600);

    }

    public void setup() {
        Log.i("Selam","123");
        PGraphics graph = createGraphics(100,100);
        graph.beginDraw();
        graph.text("Selam",50,50);
        graph.endDraw();

    }

    public void draw() {
        if (mousePressed) {
            ellipse(mouseX, mouseY, 50, 50);
        }
    }
   public void sss(){}

}